# CaloBridge 3 — version diagnostique de liaison 0.1.0

**Objectif de cette premiere compilation :** prouver que l'application Android recoit
la demande de CaloFlow 2 R2 Etape 4, reconnait le protocole 3, puis revient
uniquement vers l'origine `https://caloflow2.netlify.app/`.

- Package Android : `com.caloflow.calobridge3` (separe de CaloBridge 1 et 2).
- URI entrante : `calobridge3://sync`.
- Retour : `https://caloflow2.netlify.app/#calobridge3=<JSON-UTF8-base64url>`.
- **Aucune permission Sante Connect**, aucune lecture Garmin ni calorie inventee.
- Le code d'erreur `READ_FAILED` est volontaire pour cette premiere liaison.
- Si le WebAPK cible est absent ou ambigu, l'APK **n'ouvre aucun navigateur au hasard**
  et presente l'ecran de diagnostic; essai manuel possible tant que la demande est fraiche.
- PWA non publiee/modifiee par cette archive.
- Version Android debug signee automatiquement par GitHub Actions avec une cle ephemere
  : a supprimer avant l'installation d'une version definitivement signee.

Pour compiler sur GitHub Actions, deposer ce ZIP sous le nom
`calobridge3-source.zip` a la racine du depot et le workflow
`.github/workflows/build-calobridge3-linktest.yml`. Le workflow extrait ce
projet et produit `app-debug.apk` avec tests unitaires et verification de signature.

**ATTENTION** : un ZIP de sources n'est pas un APK ; l'APK n'existe qu'apres
une execution reussie du workflow.
