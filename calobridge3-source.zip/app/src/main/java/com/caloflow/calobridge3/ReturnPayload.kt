package com.caloflow.calobridge3

import android.util.Base64
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.time.Instant

/** TEST UNIQUEMENT : aucun resultat calorique n'est fabrique ou importe. */
internal object ReturnPayload {
    fun testError(request: SyncRequest, now: Instant = Instant.now()): String {
        val result = JSONObject().apply {
            put("format", "caloflow2.return")
            put("protocolVersion", 3)
            put("client", BridgeConfig.CLIENT)
            put("requestId", request.requestId)
            put("day", request.day)
            put("generatedAt", now.toString())
            put("status", "error")
            put("code", "READ_FAILED")
        }
        val bytes = result.toString().toByteArray(StandardCharsets.UTF_8)
        require(bytes.size <= BridgeConfig.MAX_JSON_BYTES)
        val encoded = Base64.encodeToString(bytes, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)
        return BridgeConfig.RETURN_URL + BridgeConfig.RETURN_HASH_PREFIX + encoded
    }
}
