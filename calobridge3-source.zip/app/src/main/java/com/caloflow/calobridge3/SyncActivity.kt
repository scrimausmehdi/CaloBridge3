package com.caloflow.calobridge3

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import java.time.Instant

/** Activite courte translucide; aucun Health Connect dans cette version de test. */
class SyncActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        @Suppress("DEPRECATION")
        overridePendingTransition(0, 0)
        handle(intent?.data)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handle(intent.data)
    }

    private fun handle(uri: Uri?) {
        val parameters = try {
            if (uri?.scheme != BridgeConfig.URI_SCHEME || uri.host != BridgeConfig.URI_HOST) null
            else {
                val keys = uri.queryParameterNames
                if (keys.any { uri.getQueryParameters(it).size != 1 }) null
                else keys.associateWith { uri.getQueryParameter(it) }
            }
        } catch (_: Exception) { null }
        val request = parameters?.let { RequestValidator.parse(it) }
        if (request == null) {
            DiagnosticStore.updateMessage(this, "Demande invalide ou expirée. Relance Synchroniser depuis CaloFlow 2.")
            showDiagnostic()
            end()
            return
        }
        val url = ReturnPayload.testError(request, Instant.now())
        val route = ReturnRouter.open(this, url)
        if (route is RoutingResult.NotLaunched) {
            DiagnosticStore.save(this, url, request.issuedAt, route.reason)
            showDiagnostic()
        } else {
            DiagnosticStore.save(this, url, request.issuedAt,
                "Retour de test envoyé à CaloFlow 2. Le code READ_FAILED est attendu pour cette version.")
        }
        end()
    }

    private fun showDiagnostic() {
        startActivity(Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        })
    }
    private fun end() {
        finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(0, 0)
    }
}
