package com.caloflow.calobridge3

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Ecran de diagnostic accessible manuellement, jamais necessaire au flux nominal. */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(48, 64, 48, 48)
        }
        fun text(label: String, size: Float): TextView = TextView(this).apply {
            this.text = label
            textSize = size
            setPadding(0, 12, 0, 20)
        }
        root.addView(text("CaloBridge 3 — Test de liaison", 23f))
        root.addView(text(
            "Cette version vérifie uniquement le passage de CaloFlow 2 à Android et le retour. " +
            "Elle ne lit pas Santé Connect et ne transmet aucune calorie.\n\n" +
            "Pour lancer le test, utilise le bouton Synchroniser dans la PWA CaloFlow 2 " +
            "installée sur https://caloflow2.netlify.app/.\n\n" +
            "Si le retour réussit, le message READ_FAILED est normal : la lecture santé n'est pas encore activée.",
            16f
        ))
        val status = text(DiagnosticStore.message(this), 15f)
        root.addView(status)
        val retry = Button(this).apply { text = "Retenter le retour vers la PWA" }
        retry.setOnClickListener {
            val url = DiagnosticStore.returnUrlIfFresh(this)
            val message = if (url == null) "Demande expirée. Relance Synchroniser depuis la PWA."
            else when (val result = ReturnRouter.open(this, url)) {
                is RoutingResult.Launched -> "Retour envoyé ; vérifie la PWA."
                is RoutingResult.NotLaunched -> result.reason
            }
            DiagnosticStore.updateMessage(this, message)
            status.text = message
        }
        root.addView(retry, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)
    }
}
