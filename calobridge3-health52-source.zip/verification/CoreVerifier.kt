import com.caloflow.calobridge3.*
import java.time.Instant
import java.time.LocalDate

fun main() {
    val now=Instant.parse("2026-10-18T19:11:54Z")
    val m=linkedMapOf<String,String?>(
        "protocolVersion" to "3", "client" to "caloflow2-rebuild",
        "requestId" to "dc88dcc4-d23d-4d7b-9460-19c1b05a06b2",
        "issuedAt" to (now.epochSecond-10).toString(),
        "day" to "2026-10-18", "timeZone" to "Europe/Paris", "categories" to "total,active,sessions")
    var checks=0
    fun yes(b:Boolean,msg:String) { check(b) {msg}; checks++ }
    fun bad(key:String,value:String?) { val map=m.toMutableMap();map[key]=value;yes(runCatching { BridgeCore.parse(map,now) }.isFailure,"Expected reject $key") }
    val req=BridgeCore.parse(m,now)
    yes(req.start.toString()=="2026-10-17T22:00:00Z","midnight Paris")
    yes(req.end==now,"end time")
    bad("protocolVersion","1");bad("client","bad");bad("requestId","bad");bad("day","2026-10-19");bad("day","2026-02-30");bad("timeZone","UTC");bad("categories","steps");bad("issuedAt",(now.epochSecond-301).toString());bad("issuedAt",(now.epochSecond+61).toString());bad("issuedAt","bad")
    yes(BridgeCore.dayDurationHours(LocalDate.parse("2026-03-29"))==23L,"DST march")
    yes(BridgeCore.dayDurationHours(LocalDate.parse("2026-10-25"))==25L,"DST october")
    yes(BridgeCore.dayDurationHours(LocalDate.parse("2026-10-18"))==24L,"ordinary day")
    yes(BridgeCore.isStillValid(req,now.plusSeconds(250)),"fresh token")
    yes(!BridgeCore.isStillValid(req,now.plusSeconds(310)),"expired token")
    val r=ScanDiagnostics("2026-10-18",true,true,true,false,true,2,0,1,setOf("package.other"),true,"DIAG").safeText()
    yes(r.contains("package.other") && !r.contains("2 kcal"),"private report")
    println("STATIC CORE VERIFIER PASSED: $checks scenarios")
}
