plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.caloflow.calobridge3"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.caloflow.calobridge3"
        minSdk = 34
        targetSdk = 36
        versionCode = 2
        versionName = "0.2.0-health-read-diagnostic"
    }
    buildTypes {
        getByName("release") { isMinifyEnabled = false }
        getByName("debug") { isDebuggable = true }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    testOptions { unitTests.isReturnDefaultValues = true }
}

dependencies {
    implementation("androidx.activity:activity-ktx:1.10.1")
    implementation("androidx.health.connect:connect-client:1.1.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
    testImplementation("junit:junit:4.13.2")
}
