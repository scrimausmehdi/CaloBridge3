package com.caloflow.calobridge3

import org.junit.Assert.*
import org.junit.Test
import java.time.Instant
import java.time.LocalDate

class BridgeCoreTest {
    private val now = Instant.parse("2026-10-18T19:11:54Z")
    private fun valid() = mutableMapOf<String, String?>(
        "protocolVersion" to "3", "client" to "caloflow2-rebuild",
        "requestId" to "dc88dcc4-d23d-4d7b-9460-19c1b05a06b2",
        "issuedAt" to (now.epochSecond - 10).toString(),
        "day" to "2026-10-18", "timeZone" to "Europe/Paris",
        "categories" to "total,active,sessions")
    private fun rejected(values: Map<String,String?>) {
        try { BridgeCore.parse(values, now); fail("Should reject request") }
        catch (e: IllegalArgumentException) { assertTrue(e.message in listOf("READ_FAILED", "INCOMPATIBLE_VERSION")) }
    }

    @Test fun acceptsValidRequest() {
        val r = BridgeCore.parse(valid(), now)
        assertEquals("2026-10-18", r.day.toString())
        assertEquals("2026-10-17T22:00:00Z", r.start.toString())
        assertEquals(now, r.end)
    }
    @Test fun rejectsUnexpectedCallbackEvenWithValidFields() {
        rejected(valid().apply { set("returnUrl", "https://malicious.example") })
    }
    @Test fun rejectsUppercaseUuidToMatchPwaContract() {
        rejected(valid().apply { set("requestId", "DC88DCC4-D23D-4D7B-9460-19C1B05A06B2") })
    }
    @Test fun rejectsWrongClient() { rejected(valid().apply { set("client", "other") }) }
    @Test fun rejectsOldProtocol() { rejected(valid().apply { set("protocolVersion", "1") }) }
    @Test fun rejectsInvalidUuid() { rejected(valid().apply { set("requestId", "1234") }) }
    @Test fun rejectsWrongTimezone() { rejected(valid().apply { set("timeZone", "UTC") }) }
    @Test fun rejectsOtherCategories() { rejected(valid().apply { set("categories", "steps") }) }
    @Test fun rejectsFutureDay() { rejected(valid().apply { set("day", "2026-10-19") }) }
    @Test fun rejectsImpossibleDate() { rejected(valid().apply { set("day", "2026-02-30") }) }
    @Test fun rejectsExpiredRequest() { rejected(valid().apply { set("issuedAt", (now.epochSecond-301).toString()) }) }
    @Test fun acceptsExactlyFiveMinutes() { BridgeCore.parse(valid().apply {set("issuedAt",(now.epochSecond-300).toString())},now) }
    @Test fun rejectsDistantFutureRequest() { rejected(valid().apply {set("issuedAt",(now.epochSecond+61).toString())}) }
    @Test fun acceptsSixtySecondsFutureTolerance() { BridgeCore.parse(valid().apply {set("issuedAt",(now.epochSecond+60).toString())},now) }
    @Test fun rejectsNonDecimalEpoch() { rejected(valid().apply { set("issuedAt", "1.5") }) }
    @Test fun parisMarchDayHas23Hours() { assertEquals(23,BridgeCore.dayDurationHours(LocalDate.parse("2026-03-29"))) }
    @Test fun parisOctoberDayHas25Hours() { assertEquals(25,BridgeCore.dayDurationHours(LocalDate.parse("2026-10-25"))) }
    @Test fun ordinaryDayHas24Hours() { assertEquals(24,BridgeCore.dayDurationHours(LocalDate.parse("2026-10-18"))) }
    @Test fun dayTruncatesAtTomorrowForHistoricalDay() {
        val v=valid().apply {set("day", "2026-10-17")}
        assertEquals("2026-10-17T22:00:00Z",BridgeCore.parse(v,now).end.toString())
    }
    @Test fun nullOriginDiagnosticsStayAnonymous() {
        val report=ScanDiagnostics("2026-10-18",true,true,true,false,true,2,0,1,setOf("org.other"),true,"LECTURE_EFFECTUEE_DIAGNOSTIC").safeText()
        assertTrue(report.contains("org.other")); assertFalse(report.contains("123 kcal"))
    }
    @Test fun expirationGateChecksSubsequentPermissionReturn() {
        val req=BridgeCore.parse(valid(),now)
        assertTrue(BridgeCore.isStillValid(req,now.plusSeconds(10)))
        assertFalse(BridgeCore.isStillValid(req,now.plusSeconds(301)))
    }
}
