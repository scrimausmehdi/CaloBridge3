package com.caloflow.calobridge3

import org.junit.Assert.*
import org.junit.Test
import java.time.Instant

class RequestValidatorTest {
    private val now = Instant.parse("2026-10-17T21:00:00Z")
    private val valid = mapOf(
        "protocolVersion" to "3", "client" to "caloflow2-rebuild",
        "requestId" to "71e48c4a-85fd-4c5d-9803-7c7758902813",
        "issuedAt" to now.epochSecond.toString(), "day" to "2026-10-17",
        "timeZone" to "Europe/Paris", "categories" to "total,active,sessions"
    )
    @Test fun validRequest() { assertNotNull(RequestValidator.parse(valid, now)) }
    @Test fun wrongProtocol() { assertNull(RequestValidator.parse(valid + ("protocolVersion" to "1"), now)) }
    @Test fun wrongClient() { assertNull(RequestValidator.parse(valid + ("client" to "other"), now)) }
    @Test fun extraCallbackRejected() { assertNull(RequestValidator.parse(valid + ("callback" to "https://evil.example"), now)) }
    @Test fun uuidV4Required() { assertNull(RequestValidator.parse(valid + ("requestId" to "oops"), now)) }
    @Test fun wrongTimeZone() { assertNull(RequestValidator.parse(valid + ("timeZone" to "UTC"), now)) }
    @Test fun differentCategories() { assertNull(RequestValidator.parse(valid + ("categories" to "active"), now)) }
    @Test fun expired() { assertNull(RequestValidator.parse(valid + ("issuedAt" to (now.epochSecond - 301).toString()), now)) }
    @Test fun futureClock() { assertNull(RequestValidator.parse(valid + ("issuedAt" to (now.epochSecond + 61).toString()), now)) }
    @Test fun withinClockTolerance() { assertNotNull(RequestValidator.parse(valid + ("issuedAt" to (now.epochSecond + 60).toString()), now)) }
    @Test fun malformedDay() { assertNull(RequestValidator.parse(valid + ("day" to "2026-02-30"), now)) }
    @Test fun futureDay() { assertNull(RequestValidator.parse(valid + ("day" to "2026-10-18"), now)) }
    @Test fun missingField() { assertNull(RequestValidator.parse(valid - "day", now)) }
}
