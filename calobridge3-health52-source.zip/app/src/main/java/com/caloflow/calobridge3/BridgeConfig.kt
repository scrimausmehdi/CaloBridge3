package com.caloflow.calobridge3

/** Identite fixe : les callbacks entrants ne peuvent jamais imposer un autre domaine. */
internal object BridgeConfig {
    const val PACKAGE_NAME = "com.caloflow.calobridge3"
    const val URI_SCHEME = "calobridge3"
    const val URI_HOST = "sync"
    const val CLIENT = "caloflow2-rebuild"
    const val PROTOCOL = "3"
    const val RETURN_URL = "https://caloflow2.netlify.app/"
    const val RETURN_HASH_PREFIX = "#calobridge3="
    const val MAX_JSON_BYTES = 12_288
    const val MAX_AGE_SECONDS = 300L
    const val FUTURE_TOLERANCE_SECONDS = 60L
}
