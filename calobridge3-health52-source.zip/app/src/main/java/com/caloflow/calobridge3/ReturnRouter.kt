package com.caloflow.calobridge3

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build

internal sealed interface RoutingResult {
    data object Launched : RoutingResult
    data class NotLaunched(val reason: String) : RoutingResult
}

/**
 * Ne choisit JAMAIS le premier WebAPK par hasard.
 * Si le WebAPK exact ne peut etre cible de maniere non ambigue, refuser
 * plutot que d'ouvrir les donnees dans un onglet Chrome sans localStorage.
 */
internal object ReturnRouter {
    private const val WEBAPK_PREFIX = "org.chromium.webapk."

    fun open(context: Context, url: String): RoutingResult {
        val uri = Uri.parse(url)
        if (uri.scheme != "https" || uri.host != "caloflow2.netlify.app" || uri.path != "/") {
            return RoutingResult.NotLaunched("Destination inattendue : retour bloque.")
        }
        val probe = Intent(Intent.ACTION_VIEW, Uri.parse(BridgeConfig.RETURN_URL)).apply {
            addCategory(Intent.CATEGORY_BROWSABLE)
        }
        val matches = try {
            val pm = context.packageManager
            val resolved = if (Build.VERSION.SDK_INT >= 33) {
                pm.queryIntentActivities(probe, PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_DEFAULT_ONLY.toLong()))
            } else {
                @Suppress("DEPRECATION")
                pm.queryIntentActivities(probe, PackageManager.MATCH_DEFAULT_ONLY)
            }
            resolved.map { it.activityInfo.packageName }
                .distinct()
                .filter { it.startsWith(WEBAPK_PREFIX) }
        } catch (_: Exception) {
            emptyList()
        }
        if (matches.size != 1) {
            return RoutingResult.NotLaunched(
                if (matches.isEmpty()) "Aucune PWA CaloFlow 2 installée reconnue pour le domaine prévu."
                else "Plusieurs WebAPK peuvent recevoir ce retour ; sélection automatique interdite."
            )
        }
        val open = Intent(Intent.ACTION_VIEW, uri).apply {
            addCategory(Intent.CATEGORY_BROWSABLE)
            setPackage(matches.single())
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
        }
        return try {
            context.startActivity(open)
            RoutingResult.Launched
        } catch (_: Exception) {
            RoutingResult.NotLaunched("Le WebAPK sélectionné n'a pas pu être ouvert.")
        }
    }
}
