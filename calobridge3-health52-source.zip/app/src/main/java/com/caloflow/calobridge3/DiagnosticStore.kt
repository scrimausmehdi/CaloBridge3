package com.caloflow.calobridge3

import android.content.Context
import java.time.Instant

/** Stockage prive du seul diagnostic, sans donnees de sante. */
internal object DiagnosticStore {
    private const val PREFS = "calobridge3_link_test"
    private const val URL = "pending_return"
    private const val ISSUED = "issued_at"
    private const val MESSAGE = "last_message"
    private const val REPORT = "last_health_connect_report"

    fun save(context: Context, url: String, issuedAt: Long, message: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(URL, url)
            .putLong(ISSUED, issuedAt)
            .putString(MESSAGE, message)
            .apply()
    }
    fun message(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(MESSAGE, "Aucun test reçu. Lance Synchroniser depuis CaloFlow 2.").orEmpty()

    fun returnUrlIfFresh(context: Context): String? {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val issued = prefs.getLong(ISSUED, -1)
        if (issued < 0 || Instant.now().epochSecond - issued > BridgeConfig.MAX_AGE_SECONDS ||
            Instant.now().epochSecond - issued < -BridgeConfig.FUTURE_TOLERANCE_SECONDS) return null
        return prefs.getString(URL, null)
    }
    fun write(context: Context, report: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(REPORT, report.take(3000)).apply()
    }
    fun read(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(REPORT, "Aucune lecture Santé Connect encore réalisée.").orEmpty()

    fun updateMessage(context: Context, text: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(MESSAGE, text).apply()
    }
}
