package com.caloflow.calobridge3

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeParseException

/** Validation pure Kotlin pour etre testee sans simulateur Android. */
internal data class SyncRequest(
    val requestId: String,
    val issuedAt: Long,
    val day: String,
)

internal object RequestValidator {
    private val UUID_V4 = Regex("^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$")
    private val DAY = Regex("^\\d{4}-\\d{2}-\\d{2}$")
    private val REQUIRED = setOf("protocolVersion", "client", "requestId", "issuedAt", "day", "timeZone", "categories")
    private val PARIS = ZoneId.of("Europe/Paris")

    fun parse(parameters: Map<String, String?>, now: Instant = Instant.now()): SyncRequest? {
        if (parameters.keys != REQUIRED) return null
        if (parameters["protocolVersion"] != BridgeConfig.PROTOCOL) return null
        if (parameters["client"] != BridgeConfig.CLIENT) return null
        if (parameters["timeZone"] != "Europe/Paris") return null
        if (parameters["categories"] != "total,active,sessions") return null
        val requestId = parameters["requestId"] ?: return null
        if (!UUID_V4.matches(requestId)) return null
        val issuedAt = parameters["issuedAt"]?.toLongOrNull() ?: return null
        if (issuedAt < 0) return null
        val age = now.epochSecond - issuedAt
        if (age > BridgeConfig.MAX_AGE_SECONDS || age < -BridgeConfig.FUTURE_TOLERANCE_SECONDS) return null
        val day = parameters["day"] ?: return null
        if (!DAY.matches(day)) return null
        val requested = try { LocalDate.parse(day) } catch (_: DateTimeParseException) { return null }
        val today = now.atZone(PARIS).toLocalDate()
        if (requested.isAfter(today)) return null
        return SyncRequest(requestId, issuedAt, day)
    }
}
