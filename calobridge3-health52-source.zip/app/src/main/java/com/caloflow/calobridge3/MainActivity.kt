package com.caloflow.calobridge3

import android.app.Activity
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.view.Gravity
import android.widget.Button
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var diagnostic: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30, 36, 30, 24)
        }
        val title = TextView(this).apply {
            text = "CaloBridge 3 — Santé Connect (étape 5.2)"
            textSize = 21f
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val intro = TextView(this).apply {
            text = "La synchronisation se lance depuis CaloFlow 2. Ce prototype lit seulement Santé Connect et affiche ici un diagnostic de disponibilité. Les calories ne sont pas encore transmises à la roue."
            textSize = 15f
            setPadding(0, 24, 0, 28)
        }
        diagnostic = TextView(this).apply {
            text = DiagnosticStore.read(this@MainActivity)
            textSize = 15f
            movementMethod = ScrollingMovementMethod()
            setPadding(0, 10, 0, 20)
        }
        content.addView(title)
        content.addView(intro)
        content.addView(diagnostic)
        val lastRoute = TextView(this).apply {
            text = DiagnosticStore.message(this@MainActivity)
            textSize = 14f
            setPadding(0, 16, 0, 16)
        }
        content.addView(lastRoute)
        val retry = Button(this).apply { text = "Retenter le retour vers la PWA" }
        retry.setOnClickListener {
            val url = DiagnosticStore.returnUrlIfFresh(this)
            val status = if (url == null) "Demande expirée. Relance Synchroniser depuis CaloFlow 2."
                else when (val route = ReturnRouter.open(this, url)) {
                    is RoutingResult.Launched -> "Retour envoyé ; vérifie CaloFlow 2."
                    is RoutingResult.NotLaunched -> route.reason
                }
            DiagnosticStore.updateMessage(this, status)
            lastRoute.text = status
        }
        content.addView(retry, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT))
        val scroll = ScrollView(this).apply { addView(content) }
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        if (::diagnostic.isInitialized) diagnostic.text = DiagnosticStore.read(this)
    }
}
