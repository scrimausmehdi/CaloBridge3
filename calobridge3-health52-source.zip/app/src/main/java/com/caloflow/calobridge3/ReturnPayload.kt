package com.caloflow.calobridge3

import android.util.Base64
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.time.Instant

/** Etape 5.2 : diagnostic de lecture uniquement, jamais de calories dans le retour. */
internal object ReturnPayload {
    private val allowedCodes = setOf("READ_FAILED", "NO_SOURCE", "HEALTH_UNAVAILABLE",
        "PERMISSION_DENIED", "INCOMPATIBLE_VERSION", "RETURN_TARGET_MISMATCH")

    fun error(request: SyncRequest, code: String, now: Instant = Instant.now()): String {
        require(code in allowedCodes) { "Code de retour inattendu" }
        val result = JSONObject().apply {
            put("format", "caloflow2.return")
            put("protocolVersion", 3)
            put("client", BridgeConfig.CLIENT)
            put("requestId", request.requestId)
            put("day", request.day)
            put("generatedAt", now.toString())
            put("status", "error")
            put("code", code)
        }
        val bytes = result.toString().toByteArray(StandardCharsets.UTF_8)
        require(bytes.size <= BridgeConfig.MAX_JSON_BYTES)
        val encoded = Base64.encodeToString(bytes, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)
        return BridgeConfig.RETURN_URL + BridgeConfig.RETURN_HASH_PREFIX + encoded
    }

    fun testError(request: SyncRequest, now: Instant = Instant.now()): String =
        error(request, "READ_FAILED", now)
}
