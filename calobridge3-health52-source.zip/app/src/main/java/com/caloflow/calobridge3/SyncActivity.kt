package com.caloflow.calobridge3

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.ExerciseSessionRecord
import androidx.health.connect.client.records.TotalCaloriesBurnedRecord
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import java.time.Instant

/** Short translucent Activity; permissions are the ONLY expected Android UI in stage 5.2. */
class SyncActivity : ComponentActivity() {
    private val wanted = setOf(
        HealthPermission.getReadPermission(TotalCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(ExerciseSessionRecord::class),
    )
    private val permissionLauncher = registerForActivityResult(
        PermissionController.createRequestPermissionResultContract()
    ) { granted ->
        val req = current
        if (req == null || !BridgeCore.isStillValid(req)) {
            finishWith(req, "READ_FAILED", "Demande périmée pendant l'autorisation.")
        } else if (!granted.containsAll(wanted)) {
            finishWith(req, "PERMISSION_DENIED", "Autorisations de lecture refusées.")
        } else {
            inspect(req)
        }
    }
    private var current: BridgeCore.Request? = null
    private var running = false
    private var completed = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        @Suppress("DEPRECATION")
        overridePendingTransition(0, 0)
        handleIncoming(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // A second click must not steal the first request or import anything twice.
        if (running || completed) return
        setIntent(intent)
        handleIncoming(intent)
    }

    private fun handleIncoming(intent: Intent?) {
        if (running || completed) return
        val uri = intent?.data
        val values = runCatching {
            if (uri?.scheme != BridgeCore.SCHEME || uri.host != BridgeConfig.URI_HOST) return@runCatching emptyMap()
            val keys = uri.queryParameterNames
            if (keys.any { uri.getQueryParameters(it).size != 1 }) return@runCatching emptyMap()
            keys.associateWith { uri.getQueryParameter(it) }
        }.getOrDefault(emptyMap())
        val req = runCatching { BridgeCore.parse(values) }.getOrNull()
        if (req == null) {
            DiagnosticStore.write(this, "Lien de synchronisation invalide ou périmé. Relance depuis CaloFlow 2.")
            // Invalid requests do not contain a trustworthy requestId; no PWA URL is opened.
            closeSilently()
            return
        }
        current = req
        running = true
        val status = runCatching { HealthConnectClient.getSdkStatus(this) }
            .getOrElse { finishWith(req, "HEALTH_UNAVAILABLE", "Santé Connect inaccessible."); return }
        if (status != HealthConnectClient.SDK_AVAILABLE) {
            finishWith(req, "HEALTH_UNAVAILABLE", "Santé Connect indisponible (statut $status).")
            return
        }
        lifecycleScope.launch {
            try {
                val health = HealthConnectClient.getOrCreate(this@SyncActivity)
                val granted = health.permissionController.getGrantedPermissions()
                val missing = wanted - granted
                if (missing.isNotEmpty()) {
                    // The Activity MUST stay alive while Android shows the permission screen.
                    permissionLauncher.launch(missing)
                } else inspect(req)
            } catch (error: SecurityException) {
                finishWith(req, "PERMISSION_DENIED", "Permissions Santé Connect indisponibles.")
            } catch (error: Exception) {
                finishWith(req, "READ_FAILED", "Échec de préparation de la lecture.")
            }
        }
    }

    private fun inspect(req: BridgeCore.Request) {
        lifecycleScope.launch {
            try {
                if (!BridgeCore.isStillValid(req)) {
                    finishWith(req, "READ_FAILED", "Demande expirée : relance depuis CaloFlow 2.")
                    return@launch
                }
                val health = HealthConnectClient.getOrCreate(this@SyncActivity)
                val reading = withTimeout(35_000L) { HealthReader(health).inspect(req) }
                DiagnosticStore.write(this@SyncActivity, reading.safeText())
                // Stage 5.2 is READ DIAGNOSTIC ONLY. Do not claim to transmit valid calorie values.
                finishWith(req, if (reading.code == "NO_SOURCE") "NO_SOURCE" else "READ_FAILED", null)
            } catch (error: SecurityException) {
                finishWith(req, "PERMISSION_DENIED", "Permissions révoquées ou indisponibles.")
            } catch (error: Exception) {
                finishWith(req, "READ_FAILED", "Erreur de lecture de Santé Connect.")
            }
        }
    }

    private fun finishWith(req: BridgeCore.Request?, code: String, diagnostic: String?) {
        if (completed) return
        completed = true
        if (diagnostic != null) DiagnosticStore.write(this, diagnostic)
        var returned = false
        if (req != null && BridgeCore.isStillValid(req, Instant.now())) {
            val validated = SyncRequest(req.requestId, req.issuedAt, req.day.toString())
            val url = ReturnPayload.error(validated, code)
            val result = ReturnRouter.open(this, url)
            DiagnosticStore.save(this, url, req.issuedAt, when (result) {
                is RoutingResult.Launched -> "Retour transmis à CaloFlow 2. Ouvre CaloBridge 3 pour consulter le diagnostic de lecture."
                is RoutingResult.NotLaunched -> result.reason
            })
            returned = result is RoutingResult.Launched
        }
        if (!returned) {
            DiagnosticStore.updateMessage(this, "Retour automatique indisponible ou demande expirée. " +
                "Ouvre CaloBridge 3 pour le diagnostic et retente le retour si la demande est encore valable.")
            startActivity(Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            })
        }
        closeSilently()
    }

    private fun closeSilently() {
        finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(0, 0)
    }
}
