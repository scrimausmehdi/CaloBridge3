package com.caloflow.calobridge3

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class PermissionsRationaleActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(TextView(this).apply {
            textSize = 17f
            setPadding(36, 65, 36, 36)
            text = "CaloBridge 3 lit les calories totales, les calories actives et les séances " +
                "de Santé Connect seulement lorsque tu appuies sur Synchroniser dans CaloFlow 2. " +
                "Aucune donnée de santé n'est transmise à GitHub ni à un serveur. " +
                "Tu peux retirer ces autorisations dans les réglages de Santé Connect."
        })
    }
}
