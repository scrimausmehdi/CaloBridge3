package com.caloflow.calobridge3

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit

object BridgeCore {
    const val SOURCE = "nl.appyhapps.healthsync"
    const val CLIENT = BridgeConfig.CLIENT
    const val PROTOCOL = BridgeConfig.PROTOCOL
    const val SCHEME = BridgeConfig.URI_SCHEME
    const val MAX_AGE_SECONDS = BridgeConfig.MAX_AGE_SECONDS
    const val FUTURE_TOLERANCE_SECONDS = BridgeConfig.FUTURE_TOLERANCE_SECONDS
    val ZONE: ZoneId = ZoneId.of("Europe/Paris")

    data class Request(
        val requestId: String,
        val issuedAt: Long,
        val day: LocalDate,
        val start: Instant,
        val end: Instant,
    )

    // Intentionally pure Kotlin: executable on the JVM without Android dependencies.
    fun parse(values: Map<String, String?>, now: Instant = Instant.now()): Request {
        val validated = RequestValidator.parse(values, now)
            ?: throw IllegalArgumentException("INCOMPATIBLE_VERSION")
        val day = LocalDate.parse(validated.day)
        val start = day.atStartOfDay(ZONE).toInstant()
        val end = minOf(now, day.plusDays(1).atStartOfDay(ZONE).toInstant())
        require(end.isAfter(start)) { "READ_FAILED" }
        return Request(validated.requestId, validated.issuedAt, day, start, end)
    }

    fun isStillValid(request: Request, now: Instant = Instant.now()): Boolean =
        now.epochSecond - request.issuedAt in -FUTURE_TOLERANCE_SECONDS..MAX_AGE_SECONDS

    fun dayDurationHours(day: LocalDate): Long =
        ChronoUnit.HOURS.between(day.atStartOfDay(ZONE).toInstant(), day.plusDays(1).atStartOfDay(ZONE).toInstant())
}

// Counts only; no health measurements or record titles are serialized to local diagnostics.
data class ScanDiagnostics(
    val day: String,
    val sdkAvailable: Boolean,
    val permissionsGranted: Boolean,
    val totalFound: Boolean,
    val activeFound: Boolean,
    val sessionsFound: Boolean,
    val totalRecords: Int,
    val activeRecords: Int,
    val sessionRecords: Int,
    val otherSources: Set<String>,
    val partial: Boolean,
    val code: String,
    val minActiveIntervalMinutes: Long? = null,
    val maxActiveIntervalMinutes: Long? = null,
    val overlappingActiveIntervals: Boolean = false,
    val crossingActiveIntervals: Boolean = false,
    val duplicateRecordIds: Boolean = false,
    val aggregationAvailable: Boolean = true,
) {
    fun safeText(): String = buildString {
        append("Jour : $day\nSanté Connect disponible : $sdkAvailable\n")
        append("Permissions de lecture accordées : $permissionsGranted\n")
        append("Source attendue : ${BridgeCore.SOURCE}\n")
        append("Total : ${if (totalFound) "présent" else "absent"} ($totalRecords enregistrements)\n")
        append("Actives : ${if (activeFound) "présentes" else "absentes"} ($activeRecords enregistrements)\n")
        append("Séances : ${if (sessionsFound) "présentes" else "absentes"} ($sessionRecords enregistrements)\n")
        append("Autres applications observées : ${if (otherSources.isEmpty()) "aucune" else otherSources.sorted().joinToString(", ")}\n")
        append("Plus petit intervalle actif : ${minActiveIntervalMinutes?.toString() ?: "inconnu"} min\n")
        append("Plus grand intervalle actif : ${maxActiveIntervalMinutes?.toString() ?: "inconnu"} min\n")
        append("Chevauchement d'intervalles actifs : $overlappingActiveIntervals\n")
        append("Intervalle traversant les bornes du jour : $crossingActiveIntervals\n")
        append("Identifiants de relevés répétés : $duplicateRecordIds\n")
        append("Agrégation disponible : $aggregationAvailable\n")
        append("Données absentes ou incomplètes détectées : $partial\n")
        append("Couverture temporelle complète : non vérifiée à l’étape 5.2\nStatut : $code\n")
        append("Diagnostic uniquement : aucune calorie n'est transmise à CaloFlow 2 à l'étape 5.2.")
    }
}
