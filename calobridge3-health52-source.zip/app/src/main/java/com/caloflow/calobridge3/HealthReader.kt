package com.caloflow.calobridge3

import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.ExerciseSessionRecord
import androidx.health.connect.client.records.Record
import androidx.health.connect.client.records.TotalCaloriesBurnedRecord
import androidx.health.connect.client.records.metadata.DataOrigin
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import java.time.Duration

/**
 * Strict READ-ONLY diagnostic for stage 5.2.
 * Aggregate values are checked for existence only, never returned over Android intents.
 * Raw records are filtered by Health Sync and only their COUNTS enter diagnostics.
 * Other-source discovery is limited to package names; no private measurements.
 */
class HealthReader(private val client: HealthConnectClient) {
    private val source = setOf(DataOrigin(BridgeCore.SOURCE))
    private val MAX_RECORDS = 5000
    private val MAX_PAGES = 10

    private data class Scan<T: Record>(val records: List<T>, val truncated: Boolean)

    private suspend inline fun <reified T: Record> scan(
        range: TimeRangeFilter, origins: Set<DataOrigin>, limit: Int = MAX_RECORDS,
    ): Scan<T> {
        val list = ArrayList<T>()
        var token: String? = null
        var pages = 0
        do {
            val result = client.readRecords(
                ReadRecordsRequest<T>(timeRangeFilter = range, dataOriginFilter = origins,
                    pageSize = minOf(1000, limit - list.size), pageToken = token)
            )
            list.addAll(result.records)
            token = result.pageToken
            pages++
        } while (token != null && pages < MAX_PAGES && list.size < limit)
        return Scan(list, token != null || list.size >= limit)
    }

    suspend fun inspect(req: BridgeCore.Request): ScanDiagnostics {
        val range = TimeRangeFilter.between(req.start, req.end)
        // Aggregations use the same time period and same origin. Null is missing, not zero.
        // Failed aggregate queries must not obscure separately readable raw records.
        // No substitute values are invented if aggregation is unavailable.
        val agg = runCatching {
            client.aggregate(
                AggregateRequest(metrics = setOf(TotalCaloriesBurnedRecord.ENERGY_TOTAL,
                    ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL),
                    timeRangeFilter = range, dataOriginFilter = source)
            )
        }.getOrNull()
        val total = agg?.get(TotalCaloriesBurnedRecord.ENERGY_TOTAL)
        val active = agg?.get(ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL)
        val totalScan = scan<TotalCaloriesBurnedRecord>(range, source)
        val activeScan = scan<ActiveCaloriesBurnedRecord>(range, source)
        val sessions = scan<ExerciseSessionRecord>(range, source)

        // Detect package-origin mismatches without printing record contents or measurement amounts.
        val allOrigins = mutableSetOf<String>()
        val allTotal = scan<TotalCaloriesBurnedRecord>(range, emptySet(), limit = 1000)
        val allActive = scan<ActiveCaloriesBurnedRecord>(range, emptySet(), limit = 1000)
        val allSessions = scan<ExerciseSessionRecord>(range, emptySet(), limit = 1000)
        for (record in allTotal.records) allOrigins.add(record.metadata.dataOrigin.packageName)
        for (record in allActive.records) allOrigins.add(record.metadata.dataOrigin.packageName)
        for (record in allSessions.records) allOrigins.add(record.metadata.dataOrigin.packageName)
        allOrigins.remove(BridgeCore.SOURCE)

        val foundTotal = total != null || totalScan.records.isNotEmpty()
        val foundActive = active != null || activeScan.records.isNotEmpty()
        val foundSessions = sessions.records.isNotEmpty()
        val truncated = listOf(totalScan.truncated, activeScan.truncated, sessions.truncated,
            allTotal.truncated, allActive.truncated, allSessions.truncated).any { it }
        val noSource = !foundTotal && !foundActive && !foundSessions
        val activeSorted = activeScan.records.sortedBy { it.startTime }
        val lengths = activeSorted.map { Duration.between(it.startTime, it.endTime).toMinutes() }
        val overlap = activeSorted.zipWithNext().any { (left, right) -> right.startTime < left.endTime }
        val crosses = activeSorted.any { it.startTime < req.start || it.endTime > req.end }
        val duplicates = listOf(totalScan.records.map { it.metadata.id },
            activeScan.records.map { it.metadata.id },
            sessions.records.map { it.metadata.id }).any { ids -> ids.size != ids.toSet().size }
        return ScanDiagnostics(req.day.toString(), true, true, foundTotal, foundActive,
            foundSessions, totalScan.records.size, activeScan.records.size,
            sessions.records.size, allOrigins, truncated || noSource ||
                !foundTotal || !foundActive || !foundSessions,
            if (noSource) "NO_SOURCE" else "LECTURE_EFFECTUEE_DIAGNOSTIC",
            lengths.minOrNull(), lengths.maxOrNull(), overlap, crosses, duplicates, agg != null)
    }
}
