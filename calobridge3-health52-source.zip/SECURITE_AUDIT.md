# Audit de sécurité et de limites — étape 5.2

1. **Absence de promesse de perfection** : tests Kotlin partiels sans SDK Android. Toutes les erreurs de compilation remontées par GitHub devront être corrigées avant diffusion.
2. **Permissions** : READ_TOTAL_CALORIES_BURNED, READ_ACTIVE_CALORIES_BURNED, READ_EXERCISE uniquement ; pas d'internet, localisation, historique étendu ou écriture.
3. **Limite de confidentialité** : rapports locaux exposent `nom de package de source`, présence/absence, nombre de relevés, granularité et anomalies, sans mesures ni séances individuelles. Ne pas partager la capture si un nom de package révèle une application privée.
4. **Validation du lien entrant** : client, protocole, UUID v4, jour local, zone, 5 min et catégories stricts. Un lien forgé ne permet pas de choisir l'URL de retour.
5. **Filtrage Santé Connect** : total/actif/entraînement filtrés sur `nl.appyhapps.healthsync`. D'autres origines ne sont pas additionnées au relevé.
6. **Granularité** : les relevés bruts traversant une frontière et les chevauchements sont détectés ; aucune allocation des kcal aux séances et aucun sous-total fabriqué en 5.2.
7. **Retour PWA** : vérification d'une correspondance non ambiguë avec le WebAPK. Aucune ouverture automatique de Chrome de substitution. Si ambiguïté, le code enregistre un diagnostic et ferme sans retour.
8. **Interruption** : refus de permission, SDK inaccessible, délai expiré ou erreur de lecture rendent une erreur documentée ; aucune saisie CaloFlow 2 n'est modifiée.
9. **Première autorisation** : il faut autoriser Android à ouvrir une interface système ; il est impossible de rendre cette étape complètement invisible.
10. **Limites persistantes** : comportement Android physique, droits d'historique Health Connect, exactitude des sources Health Sync, correspondance du bon WebAPK et stabilité du certificat debug restent à vérifier.

## Audit complémentaire de code à faire avec GitHub

- Vérifier `HealthReader` contre AndroidX Health Connect 1.1.0 dans la vraie compilation.
- Contrôler `SyncActivity` lors de la première permission et de son retour (`onNewIntent`, changement de tâche, délai).
- Contrôler le résultat de `aapt dump badging`, `apksigner`, le `AndroidManifest.xml` fusionné.
- Installer sur le Xiaomi, puis vérifier que le retour ne crée pas de deuxième fenêtre et qu'aucune valeur de santé ne fuite.
