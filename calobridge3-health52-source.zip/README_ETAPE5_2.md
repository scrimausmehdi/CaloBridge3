# CaloBridge 3 — Étape 5.2 : lecture Santé Connect, version diagnostic

Date : 18 octobre 2026. Application : `com.caloflow.calobridge3`. Version : `0.2.0-health-read-diagnostic` ; `versionCode=2` ; Android 14+.

## Périmètre exact

- Reçoit le bouton `Synchroniser` depuis `https://caloflow2.netlify.app/`, protocole `3`, `calobridge3://sync`.
- Vérifie l'identité de la demande, sa date Europe/Paris et son délai de 5 minutes.
- Demande les trois permissions **lecture** de Santé Connect : calories totales, calories actives, séances sportives.
- Lit uniquement les données réellement accessibles et détecte l'origine `nl.appyhapps.healthsync` ; constate aussi les autres noms d'origine possibles sans recueillir leurs valeurs.
- Interroge les agrégats par source et période ; lit les enregistrements bruts en pagination. Compte les enregistrements et caractérise les intervalles actifs (granularité/chevauchements).
- N'extrait **aucune** mesure de santé dans les logs ni dans le lien de retour. Le diagnostic local contient seulement présence/absence, comptes, granulométrie temporelle et nom des paquets source.
- Termine le retour Android dans le WebAPK CaloFlow 2 non ambigu : ne choisit pas un navigateur par défaut silencieusement.
- **Fusion vérifiée avec les sources exactes remises depuis GitHub pour l’étape 5.1 :** `RequestValidator`, `BridgeConfig` et `ReturnRouter` conservés ; mécanisme de sauvegarde et bouton de reprise du retour conservés.
- Le `SyncActivity` de Santé Connect **ne peut plus utiliser `noHistory=true`**, car Android doit revenir de l’écran des permissions. Les autres paramètres du thème translucide restent ceux de l’étape 5.1.

### Point à ne pas confondre avec l'étape 5.3

Cet APK 5.2 est une **sonde de lecture**. Après un contrôle réussi, il renvoie encore `READ_FAILED` à la PWA **volontairement**, car la PWA n'accepte pas de diagnostic sans `snapshot`. Il ne faut PAS présenter ce code comme une erreur de lecture : ouvrir l'icône `CaloBridge 3` pour lire le diagnostic local, qui indique `LECTURE_EFFECTUEE_DIAGNOSTIC`, `NO_SOURCE`, ou le message d'erreur.

Le calcul repos/NEAT/sport et la transmission des kcal dans le snapshot JSON sont à réaliser en 5.3. Ne modifier ni les formules PWA ni son domaine pour ce test.

## Compilation GitHub

La chaîne existante GitHub Actions sait compiler Android (run précédent 39118295174). Pour ce nouveau chantier, importer **deux fichiers distincts** :

1. `calobridge3-health52-source.zip` à la racine de `scrimausmehdi/CaloBridge3`.
2. `.github/workflows/build-health-read-5_2.yml` (le fichier fourni du même nom), dans ce sous-dossier GitHub.

Le workflow déclenché par le nouveau commit lance `:app:testDebugUnitTest :app:assembleDebug`, vérifie signature, identité et version, puis publie `CaloBridge3-ETAPE5_2-APK` et `CaloBridge3-ETAPE5_2-RAPPORT` si la compilation réussit. **Ne pas déployer ni publier l'application**. Le résultat est un APK debug de test, non un APK final signé de manière pérenne.

### Attention au précédent APK

Les clés de signature debug GitHub Actions sont potentiellement différentes d'une exécution à l'autre. Si Android signale une signature incompatible, **désinstaller seulement l'ancien CaloBridge 3 de liaison**, puis installer le nouveau. Ne pas désinstaller CaloFlow 1, CaloFlow 2, CaloBridge 1/2 ni effacer le journal PWA.

## Essai Xiaomi (après compilation réussie)

- Depuis la PWA **déjà publiée** sur le domaine contractuel, choisir aujourd'hui et toucher `Synchroniser`.
- Au premier lancement, approuver les permissions Santé Connect demandées ; la boîte Android normale est attendue.
- L'application doit revenir dans **la même PWA**, avec le message `READ_FAILED` de diagnostic (ou `NO_SOURCE` si données Health Sync absentes).
- Ouvrir l'icône `CaloBridge 3` **séparément** : lire la présence des trois catégories, nombre de relevés, provenance et granularité.
- Sans recopier de chiffres de santé personnels dans GitHub, indiquer seulement si les trois catégories sont présentes, s'il existe d'autres paquets source, et si des données partielles sont signalées.

### Critère de sortie 5.2

Seule une **compilation réelle** puis un **essai sur Xiaomi** des permissions et de la lecture permettront de valider 5.2. Les tests logiciels seuls ne suffisent pas. Dans le cas d'une source partiellement disponible, discuter le contrat PWA/APK avant de passer en 5.3 pour éviter tout double comptage.

## Vie privée et sécurité

- Aucune permission `INTERNET` n'est déclarée dans l'APK.
- Aucun accès en écriture ou en arrière-plan n'est demandé.
- Aucun fichier de signature privée n'est inclus dans les sources.
- Dépôt GitHub public : ne pas y placer les données Garmin/Santé Connect ni le fragment de lien retour.
- Les diagnostics locaux sont limités aux indicateurs techniques, pas aux quantités énergétiques, aux titres des séances, ni aux identifiants bruts.

## État de validation dans l'environnement ChatGPT

- `BridgeCore.kt` et le lecteur `HealthReader.kt` ont passé une **compilation Kotlin syntaxique indépendante** ; le lecteur a été testé sur stubs typés, ce qui ne prouve pas la compatibilité avec les vraies dépendances AndroidX.
- 34 tests Kotlin combinés (13 tests 5.1 et 21 tests 5.2) et 18 scénarios indépendants de contrôle d'UUID, d'horaires, de date et de changement d'heure ont été exécutés dans une JVM locale.
- **APK non compilé ici :** cet environnement ne fournit ni Android SDK ni Gradle, et le connecteur GitHub refuse les écritures (`403`).
- Aucun essai Android 5.2 n'a encore été réalisé ; le passage par le workflow réel reste obligatoire.

## Limitations à ne pas masquer

Le binaire 5.1 fourni (SHA-256 `d2a11321e41c269d3739ce2c763df9cfcb42a5a3c55f98adf07a7a315a5c79fe`) est vérifié par son manifeste de signature. Il n’est pas possible de démontrer ici une identité binaire source → APK ; la source de référence provient du ZIP remis depuis GitHub. L’APK 5.2 n’est **pas encore compilé contre les dépendances AndroidX réelles**, car SDK/Gradle non disponibles et écriture GitHub refusée (403). Aucun test matériel 5.2 effectué.
